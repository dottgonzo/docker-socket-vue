function Page_Dashboard(){
    
     Component_Dashboard = Vue.extend({
        template: 'component!',
        data: {
            
        },
        attached: function() {
console.log("dash")

        }
    })

    
}